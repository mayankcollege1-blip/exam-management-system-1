import os
import sys
import tempfile
import unittest
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
os.environ["EXAM_DB"] = _tmp.name

import app as exam_app  # noqa: E402  (must come after EXAM_DB is set)


class FlowTest(unittest.TestCase):
    def login(self, c, email, pw):
        return c.post("/login", data={"email": email, "password": pw}, follow_redirects=True)

    def test_full_flow(self):
        admin, teacher, student = (exam_app.app.test_client() for _ in range(3))
        self.assertIn(b"Admin Dashboard", self.login(admin, "admin@college.edu", "admin123").data)
        admin.post("/admin/users", data={"name": "T", "email": "t@c.edu", "password": "secret1", "role": "teacher"})
        admin.post("/admin/subjects", data={"code": "cs101", "name": "Intro to CS"})
        student.post("/register", data={"name": "S", "email": "s@c.edu", "password": "secret1", "roll_no": "1"})

        self.login(teacher, "t@c.edu", "secret1")
        now = datetime.now()
        teacher.post("/teacher/exams/new", data={
            "title": "Quiz 1", "subject_id": 1, "duration_min": 10,
            "start_at": (now - timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M"),
            "end_at": (now + timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M")})
        teacher.post("/teacher/exams/1/questions", data={
            "text": "2+2?", "opt_a": "3", "opt_b": "4", "opt_c": "5", "opt_d": "6", "correct": "B", "marks": 2})
        teacher.post("/teacher/exams/1/publish")

        self.login(student, "s@c.edu", "secret1")
        self.assertEqual(student.get("/exam/1/take").status_code, 200)
        r = student.post("/exam/1/take", data={"q1": "B"}, follow_redirects=True)
        self.assertIn(b"2 / 2", r.data)
        self.assertIn(b"s@c.edu", teacher.get("/teacher/exams/1/results").data)
        self.assertEqual(student.get("/teacher/exams/1").status_code, 403)


if __name__ == "__main__":
    unittest.main()
