"""College Exam Management System - Flask + SQLite.

Roles: admin (manages users/subjects), teacher (creates MCQ exams),
student (attempts exams, sees results).
"""
import csv
import io
import os
import sqlite3
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, Response, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("EXAM_DB", os.path.join(BASE, "exam.db"))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-change-me")

DEFAULT_ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "admin@college.edu")
DEFAULT_ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123")


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    with open(os.path.join(BASE, "schema.sql"), encoding="utf-8") as f:
        db.executescript(f.read())
    if not db.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
        db.execute(
            "INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')",
            ("Administrator", DEFAULT_ADMIN_EMAIL,
             generate_password_hash(DEFAULT_ADMIN_PASSWORD)))
    db.commit()
    db.close()


# ---------------------------------------------------------------- helpers
def now_str():
    return datetime.now().strftime("%Y-%m-%dT%H:%M")


def login_required(role=None):
    def deco(f):
        @wraps(f)
        def wrapper(*a, **kw):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                abort(403)
            return f(*a, **kw)
        return wrapper
    return deco


def own_exam(exam_id):
    exam = get_db().execute(
        "SELECT e.*, s.name AS subject FROM exams e JOIN subjects s ON s.id=e.subject_id "
        "WHERE e.id=? AND e.teacher_id=?", (exam_id, session["user_id"])).fetchone()
    if not exam:
        abort(404)
    return exam


def create_user(name, email, password, role, roll_no=""):
    db = get_db()
    db.execute(
        "INSERT INTO users (name,email,password_hash,role,roll_no) VALUES (?,?,?,?,?)",
        (name, email, generate_password_hash(password), role, roll_no))
    db.commit()


@app.errorhandler(403)
@app.errorhandler(404)
def error(e):
    return render_template("error.html", e=e), e.code


# ------------------------------------------------------------------- auth
@app.route("/")
def index():
    return redirect(url_for("dashboard" if "user_id" in session else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        name, email = f["name"].strip(), f["email"].strip().lower()
        if not name or not email or len(f["password"]) < 6:
            flash("All fields are required and password must be 6+ characters.", "error")
        else:
            try:
                create_user(name, email, f["password"], "student", f.get("roll_no", "").strip())
                flash("Registered successfully. Please log in.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("This email is already registered.", "error")
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        user = get_db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], request.form["password"]):
            session.clear()
            session.update(user_id=user["id"], role=user["role"], name=user["name"])
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# -------------------------------------------------------------- dashboard
@app.route("/dashboard")
@login_required()
def dashboard():
    db, role = get_db(), session["role"]
    if role == "admin":
        stats = {t: db.execute(f"SELECT COUNT(*) c FROM {t}").fetchone()["c"]
                 for t in ("users", "subjects", "exams", "attempts")}
        return render_template("dashboard_admin.html", stats=stats)
    if role == "teacher":
        exams = db.execute(
            """SELECT e.*, s.name AS subject,
                 (SELECT COUNT(*) FROM questions q WHERE q.exam_id=e.id) AS qcount,
                 (SELECT COUNT(*) FROM attempts a WHERE a.exam_id=e.id
                    AND a.submitted_at IS NOT NULL) AS acount
               FROM exams e JOIN subjects s ON s.id=e.subject_id
               WHERE e.teacher_id=? ORDER BY e.start_at DESC""",
            (session["user_id"],)).fetchall()
        return render_template("dashboard_teacher.html", exams=exams)
    exams = db.execute(
        """SELECT e.*, s.name AS subject, a.id AS attempt_id,
                  a.submitted_at, a.score, a.total
           FROM exams e JOIN subjects s ON s.id=e.subject_id
           LEFT JOIN attempts a ON a.exam_id=e.id AND a.student_id=?
           WHERE e.published=1 ORDER BY e.start_at DESC""",
        (session["user_id"],)).fetchall()
    return render_template("dashboard_student.html", exams=exams, now=now_str())


# ------------------------------------------------------------------ admin
@app.route("/admin/users", methods=["GET", "POST"])
@login_required("admin")
def admin_users():
    if request.method == "POST":
        f = request.form
        role = f["role"]
        if role not in ("teacher", "student"):
            abort(400)
        try:
            create_user(f["name"].strip(), f["email"].strip().lower(),
                        f["password"], role, f.get("roll_no", "").strip())
            flash(f"{role.title()} added.", "success")
        except sqlite3.IntegrityError:
            flash("Email already exists.", "error")
        return redirect(url_for("admin_users"))
    users = get_db().execute("SELECT * FROM users ORDER BY role, name").fetchall()
    return render_template("admin_users.html", users=users)


@app.post("/admin/users/<int:uid>/delete")
@login_required("admin")
def admin_user_delete(uid):
    if uid == session["user_id"]:
        flash("You cannot delete yourself.", "error")
    else:
        db = get_db()
        db.execute("DELETE FROM users WHERE id=?", (uid,))
        db.commit()
        flash("User deleted.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/subjects", methods=["GET", "POST"])
@login_required("admin")
def admin_subjects():
    db = get_db()
    if request.method == "POST":
        try:
            db.execute("INSERT INTO subjects (code,name) VALUES (?,?)",
                       (request.form["code"].strip().upper(), request.form["name"].strip()))
            db.commit()
            flash("Subject added.", "success")
        except sqlite3.IntegrityError:
            flash("Subject code already exists.", "error")
        return redirect(url_for("admin_subjects"))
    subjects = db.execute("SELECT * FROM subjects ORDER BY code").fetchall()
    return render_template("admin_subjects.html", subjects=subjects)


@app.post("/admin/subjects/<int:sid>/delete")
@login_required("admin")
def admin_subject_delete(sid):
    db = get_db()
    db.execute("DELETE FROM subjects WHERE id=?", (sid,))
    db.commit()
    flash("Subject deleted (and its exams).", "success")
    return redirect(url_for("admin_subjects"))


# ---------------------------------------------------------------- teacher
@app.route("/teacher/exams/new", methods=["GET", "POST"])
@login_required("teacher")
def exam_new():
    db = get_db()
    subjects = db.execute("SELECT * FROM subjects ORDER BY name").fetchall()
    if request.method == "POST":
        f = request.form
        try:
            dur = int(f["duration_min"])
        except ValueError:
            dur = 0
        if not f["title"].strip() or dur <= 0 or f["end_at"] <= f["start_at"]:
            flash("Check the form: title, duration and a valid start/end window are required.", "error")
        else:
            cur = db.execute(
                "INSERT INTO exams (title,subject_id,teacher_id,start_at,end_at,duration_min) "
                "VALUES (?,?,?,?,?,?)",
                (f["title"].strip(), f["subject_id"], session["user_id"],
                 f["start_at"], f["end_at"], dur))
            db.commit()
            return redirect(url_for("exam_manage", exam_id=cur.lastrowid))
    return render_template("exam_new.html", subjects=subjects)


@app.route("/teacher/exams/<int:exam_id>")
@login_required("teacher")
def exam_manage(exam_id):
    exam = own_exam(exam_id)
    questions = get_db().execute(
        "SELECT * FROM questions WHERE exam_id=? ORDER BY id", (exam_id,)).fetchall()
    return render_template("exam_manage.html", exam=exam, questions=questions)


@app.post("/teacher/exams/<int:exam_id>/questions")
@login_required("teacher")
def question_add(exam_id):
    own_exam(exam_id)
    f = request.form
    try:
        marks = max(1, int(f.get("marks", 1)))
    except ValueError:
        marks = 1
    if f.get("correct") not in ("A", "B", "C", "D") or not f["text"].strip():
        flash("Question text and correct option are required.", "error")
    else:
        db = get_db()
        db.execute(
            "INSERT INTO questions (exam_id,text,opt_a,opt_b,opt_c,opt_d,correct,marks) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (exam_id, f["text"].strip(), f["opt_a"], f["opt_b"], f["opt_c"], f["opt_d"],
             f["correct"], marks))
        db.commit()
        flash("Question added.", "success")
    return redirect(url_for("exam_manage", exam_id=exam_id))


@app.post("/teacher/exams/<int:exam_id>/questions/<int:qid>/delete")
@login_required("teacher")
def question_delete(exam_id, qid):
    own_exam(exam_id)
    db = get_db()
    db.execute("DELETE FROM questions WHERE id=? AND exam_id=?", (qid, exam_id))
    db.commit()
    return redirect(url_for("exam_manage", exam_id=exam_id))


@app.post("/teacher/exams/<int:exam_id>/publish")
@login_required("teacher")
def exam_publish(exam_id):
    exam = own_exam(exam_id)
    db = get_db()
    count = db.execute("SELECT COUNT(*) c FROM questions WHERE exam_id=?", (exam_id,)).fetchone()["c"]
    if not exam["published"] and count == 0:
        flash("Add at least one question before publishing.", "error")
    else:
        db.execute("UPDATE exams SET published=? WHERE id=?", (0 if exam["published"] else 1, exam_id))
        db.commit()
    return redirect(url_for("exam_manage", exam_id=exam_id))


@app.post("/teacher/exams/<int:exam_id>/delete")
@login_required("teacher")
def exam_delete(exam_id):
    own_exam(exam_id)
    db = get_db()
    db.execute("DELETE FROM exams WHERE id=?", (exam_id,))
    db.commit()
    flash("Exam deleted.", "success")
    return redirect(url_for("dashboard"))


def exam_results_rows(exam_id):
    return get_db().execute(
        """SELECT u.name, u.roll_no, u.email, a.score, a.total, a.submitted_at
           FROM attempts a JOIN users u ON u.id=a.student_id
           WHERE a.exam_id=? AND a.submitted_at IS NOT NULL
           ORDER BY a.score DESC, u.name""", (exam_id,)).fetchall()


@app.route("/teacher/exams/<int:exam_id>/results")
@login_required("teacher")
def exam_results(exam_id):
    exam = own_exam(exam_id)
    return render_template("exam_results.html", exam=exam, rows=exam_results_rows(exam_id))


@app.route("/teacher/exams/<int:exam_id>/results.csv")
@login_required("teacher")
def exam_results_csv(exam_id):
    exam = own_exam(exam_id)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Name", "Roll No", "Email", "Score", "Total", "Submitted At"])
    for r in exam_results_rows(exam_id):
        w.writerow([r["name"], r["roll_no"], r["email"], r["score"], r["total"], r["submitted_at"]])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=exam_{exam['id']}_results.csv"})


# ---------------------------------------------------------------- student
def grade(db, attempt, questions, form):
    score = 0
    total = sum(q["marks"] for q in questions)
    for q in questions:
        chosen = form.get(f"q{q['id']}")
        if chosen not in ("A", "B", "C", "D"):
            chosen = None
        db.execute("INSERT OR REPLACE INTO answers (attempt_id,question_id,chosen) VALUES (?,?,?)",
                   (attempt["id"], q["id"], chosen))
        if chosen == q["correct"]:
            score += q["marks"]
    db.execute("UPDATE attempts SET submitted_at=?, score=?, total=? WHERE id=?",
               (datetime.now().isoformat(timespec="seconds"), score, total, attempt["id"]))
    db.commit()


@app.route("/exam/<int:exam_id>/take", methods=["GET", "POST"])
@login_required("student")
def take_exam(exam_id):
    db, sid = get_db(), session["user_id"]
    exam = db.execute(
        "SELECT e.*, s.name AS subject FROM exams e JOIN subjects s ON s.id=e.subject_id "
        "WHERE e.id=? AND e.published=1", (exam_id,)).fetchone()
    if not exam:
        abort(404)
    attempt = db.execute("SELECT * FROM attempts WHERE exam_id=? AND student_id=?",
                         (exam_id, sid)).fetchone()
    if attempt and attempt["submitted_at"]:
        return redirect(url_for("result", attempt_id=attempt["id"]))
    if not attempt:
        now = now_str()
        if request.method == "POST" or now < exam["start_at"] or now > exam["end_at"]:
            flash("This exam is not open right now.", "error")
            return redirect(url_for("dashboard"))
        db.execute("INSERT INTO attempts (exam_id,student_id,started_at) VALUES (?,?,?)",
                   (exam_id, sid, datetime.now().isoformat(timespec="seconds")))
        db.commit()
        attempt = db.execute("SELECT * FROM attempts WHERE exam_id=? AND student_id=?",
                             (exam_id, sid)).fetchone()

    deadline = datetime.fromisoformat(attempt["started_at"]) + timedelta(minutes=exam["duration_min"])
    questions = db.execute("SELECT * FROM questions WHERE exam_id=? ORDER BY id", (exam_id,)).fetchall()
    remaining = int((deadline - datetime.now()).total_seconds())

    if request.method == "POST":
        late = remaining < -60  # 60 s grace for network delay
        if late:
            flash("Time was over - answers were not accepted.", "error")
        grade(db, attempt, questions, {} if late else request.form)
        return redirect(url_for("result", attempt_id=attempt["id"]))
    if remaining <= 0:
        grade(db, attempt, questions, {})
        flash("Time was over before you resumed the exam.", "error")
        return redirect(url_for("result", attempt_id=attempt["id"]))
    return render_template("take_exam.html", exam=exam, questions=questions, remaining=remaining)


@app.route("/result/<int:attempt_id>")
@login_required("student")
def result(attempt_id):
    db = get_db()
    attempt = db.execute(
        """SELECT a.*, e.title, e.end_at, s.name AS subject
           FROM attempts a JOIN exams e ON e.id=a.exam_id JOIN subjects s ON s.id=e.subject_id
           WHERE a.id=? AND a.student_id=?""", (attempt_id, session["user_id"])).fetchone()
    if not attempt or not attempt["submitted_at"]:
        abort(404)
    review = None
    if now_str() > attempt["end_at"]:  # answers revealed only after the exam window closes
        review = db.execute(
            """SELECT q.*, a.chosen FROM questions q
               LEFT JOIN answers a ON a.question_id=q.id AND a.attempt_id=?
               WHERE q.exam_id=? ORDER BY q.id""", (attempt_id, attempt["exam_id"])).fetchall()
    return render_template("result.html", a=attempt, review=review)


init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG", "1") == "1")
