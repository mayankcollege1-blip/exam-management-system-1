# 📝 College Exam Management System

A simple web app for conducting online MCQ exams in a college, built with **Flask + SQLite**.

## Features

- **Admin** - add/delete teachers & students, manage subjects, see overall stats
- **Teacher** - create exams (subject, open/close window, duration), add MCQ questions with marks, publish/unpublish, view results, export results as **CSV**
- **Student** - self-register, see published exams, attempt with a **live countdown timer** (auto-submit on timeout), instant auto-graded score
- Answer review is shown to students only **after the exam window closes**
- Passwords are hashed, one attempt per student per exam, role-based access control

## Tech stack

Python 3.9+, Flask, SQLite (no extra setup), plain HTML/CSS/JS.

## Run locally

```bash
git clone <your-repo-url>
cd exam-management-system

python -m venv venv
# Windows: venv\Scripts\activate
# Linux/Mac: source venv/bin/activate

pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

**Default admin login:** `admin@college.edu` / `admin123`
(change it with env vars `ADMIN_EMAIL`, `ADMIN_PASSWORD` before the first run, and set `SECRET_KEY` for any real deployment).

## Typical workflow

1. Log in as admin → add **subjects** and **teachers**
2. Log in as teacher → **New Exam** → add questions → **Publish**
3. Students register themselves → attempt the exam in its time window
4. Teacher opens **Results** (or downloads CSV)

## Project structure

```
app.py          # Flask routes + logic
schema.sql      # SQLite tables
templates/      # Jinja2 HTML pages
static/style.css
tests/          # End-to-end test (python -m unittest discover -s tests)
```

## Run tests

```bash
python -m unittest discover -s tests -v
```

## License

MIT
